
from flask import Flask, render_template, request
import openai
import os

app = Flask(__name__)
openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/", methods=["GET", "POST"])
def index():
    image_url = None
    if request.method == "POST":
        accessories = request.form.getlist("accessories")
        uploaded_file = request.files["photo"]

        if uploaded_file:
            prompt = (
                "Создай изображение персонализированной фигурки на основе фотографии. "
                "Добавь аксессуары: " + ", ".join(accessories)
            )

            try:
                response = openai.images.generate(
                    model="dall-e-3",
                    prompt=prompt,
                    n=1,
                    size="1024x1024"
                )
                image_url = response.data[0].url
            except Exception as e:
                image_url = f"Ошибка генерации: {e}"

    return render_template("index.html", image_url=image_url)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
